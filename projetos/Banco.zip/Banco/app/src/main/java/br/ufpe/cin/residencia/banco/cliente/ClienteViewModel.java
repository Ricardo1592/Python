package br.ufpe.cin.residencia.banco.cliente;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;

public class ClienteViewModel extends AndroidViewModel {
    public ClienteViewModel(@NonNull Application application) {
        super(application);
    }
}
