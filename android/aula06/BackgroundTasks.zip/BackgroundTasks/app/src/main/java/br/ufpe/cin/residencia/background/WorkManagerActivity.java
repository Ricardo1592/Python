package br.ufpe.cin.residencia.background;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;
import androidx.work.Constraints;
import androidx.work.Data;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkInfo;
import androidx.work.WorkManager;

import java.util.concurrent.TimeUnit;


public class WorkManagerActivity extends AppCompatActivity {
    private int toastsGerados = 0;
    private int iteracoes = 50;

    public static final String KEY_CONTENT = "conteudoBaixado";
    public static final String KEY_URL_DOWNLOAD = "urlParaDownload";

    Button btnToast;
    Button btnNetwork;
    Button btnLongOperation;
    TextView contadorToasts;
    TextView contadorSegundos;
    TextView resultadoOperacaoLonga;
    TextView resultadoOperacaoRede;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        MainActivity.logThreadInfo("Rodando o onCreate");

        setContentView(R.layout.activity_tasks);

        btnToast = findViewById(R.id.btnToast);
        btnNetwork = findViewById(R.id.btnNetwork);
        btnLongOperation = findViewById(R.id.btnLongOperation);
        contadorToasts = findViewById(R.id.contadorToasts);
        contadorSegundos = findViewById(R.id.contaSegundos);
        resultadoOperacaoLonga = findViewById(R.id.resultadoOperacao);
        resultadoOperacaoRede = findViewById(R.id.resultadoOperacaoRede);

        contadorToasts.setText(getString(R.string.contadorToasts, toastsGerados));

        btnToast.setOnClickListener(
                v -> {
                    MainActivity.logThreadInfo("Callback do botão de toasts");
                    toastsGerados++;
                    String msg = getString(R.string.contadorToasts, toastsGerados);
                    Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
                    Log.d("MainThreadAPP", msg);
                    contadorToasts.setText(msg);
                }
        );

        btnLongOperation.setOnClickListener(
                v -> Toast.makeText(this, "Não implementado nesta activity", Toast.LENGTH_SHORT).show()
        );

        btnNetwork.setOnClickListener(
                v -> {
                    MainActivity.logThreadInfo("Callback do botão de operação de rede");
                    btnNetwork.setEnabled(false);
                    //pegando referência para o objeto que gerencia tarefas (works)
                    WorkManager workManager = WorkManager.getInstance(this);

                    Data dados = new Data.Builder().
                            putString(KEY_URL_DOWNLOAD, MainActivity.JSON_URL)
                            .build();
                    Constraints c = new Constraints.Builder()
                            .setRequiredNetworkType(NetworkType.CONNECTED)
                            .build();
                    //definindo uma tarefa que roda uma única vez
                    OneTimeWorkRequest tarefa = new OneTimeWorkRequest
                            .Builder(DownloadWorker.class)
                            .setInitialDelay(3, TimeUnit.SECONDS)
                            .setInputData(dados)
                            .setConstraints(c)
                            .build();
                    workManager.enqueue(tarefa);
                    LiveData<WorkInfo> statusTarefa = workManager.getWorkInfoByIdLiveData(tarefa.getId());
                    statusTarefa.observe(
                            this,
                            workInfo -> {
                                WorkInfo.State estadoAtualTarefa = workInfo.getState();
                                String msg = "";
                                boolean sucesso = false;
                                if (estadoAtualTarefa == WorkInfo.State.SUCCEEDED) {
                                    btnNetwork.setEnabled(true);
                                    sucesso = true;
                                    msg = "Funcionou!";
                                    resultadoOperacaoLonga.setText(estadoAtualTarefa.toString());
                                } else if (estadoAtualTarefa == WorkInfo.State.CANCELLED) {
                                    msg = "Cancelado";
                                    btnNetwork.setEnabled(true);
                                } else if (estadoAtualTarefa == WorkInfo.State.ENQUEUED) {
                                    msg = "Trabalho na fila...";
                                } else if (estadoAtualTarefa == WorkInfo.State.BLOCKED) {
                                    msg = "Bloqueado";
                                } else if (estadoAtualTarefa == WorkInfo.State.FAILED) {
                                    msg = "Falhou!";
                                    btnNetwork.setEnabled(true);
                                } else if (estadoAtualTarefa == WorkInfo.State.RUNNING) {
                                    msg = "Executando...";
                                } else {
                                    contadorSegundos.setText("Houve algum erro...");
                                }
                                contadorSegundos.setText(msg);
                                resultadoOperacaoLonga.setText(estadoAtualTarefa.toString());
                                if (sucesso) {
                                    Data dadosSaida = workInfo.getOutputData();
                                    String conteudoDownload = dadosSaida.getString(KEY_CONTENT);
                                    resultadoOperacaoRede.setText(conteudoDownload);
                                }
                            }
                    );
                }
        );

    }
}