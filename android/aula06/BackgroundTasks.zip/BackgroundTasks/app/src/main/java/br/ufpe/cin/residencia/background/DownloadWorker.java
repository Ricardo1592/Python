package br.ufpe.cin.residencia.background;

import static br.ufpe.cin.residencia.background.WorkManagerActivity.KEY_CONTENT;
import static br.ufpe.cin.residencia.background.WorkManagerActivity.KEY_URL_DOWNLOAD;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.work.Data;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import java.io.IOException;

public class DownloadWorker extends Worker {
    public DownloadWorker(@NonNull Context context, @NonNull WorkerParameters workerParams) {
        super(context, workerParams);
    }

    @NonNull
    @Override
    public Result doWork() {
        //qualer código dentro desse método **NAO** roda na thread principal
        //o codigo a seguir roda em uma thread de backgroun
        //nao precisamos criar uma nova thread

        MainActivity.logThreadInfo("iniciando execução do método doWork()");
        try {
            Data dadosEntrada = getInputData();
            String link = dadosEntrada.getString(KEY_URL_DOWNLOAD);
            String conteudo = MainActivity.getContentFromURL(link);
            //isso aqui funciona desse jeito, se a String tiver menos que 10Kb
            Data dadosSaida = new Data.Builder()
                    .putString(KEY_CONTENT, conteudo)
                    .build();
            MainActivity.logThreadInfo("prestes a retornar success");
            return Result.success(dadosSaida);
        } catch (IOException e) {
            MainActivity.logThreadInfo("prestes a retornar failure");
            return Result.failure();
        }
    }
}
