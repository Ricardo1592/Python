package br.ufpe.cin.residencia.datamanagement.room;

public class ProfessorDB {
}
