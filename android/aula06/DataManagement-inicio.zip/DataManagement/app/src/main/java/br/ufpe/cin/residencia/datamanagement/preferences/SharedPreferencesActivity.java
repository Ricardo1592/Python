package br.ufpe.cin.residencia.datamanagement.preferences;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Random;
import br.ufpe.cin.residencia.datamanagement.R;

public class SharedPreferencesActivity extends AppCompatActivity {
    public static final String KEY_HIGH_SCORE = "recordePontuacao";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shared_preferences);
        //maior pontuação
        TextView recorde = findViewById(R.id.high_score_text);
        TextView pontuacaoAtual = findViewById(R.id.game_score_text);
        Button jogar = findViewById(R.id.play_button);
        Button resetar = findViewById(R.id.reset_button);

        jogar.setOnClickListener(
                v -> {
                    int novoNumero = new Random().nextInt(100000);
                    pontuacaoAtual.setText(String.valueOf(novoNumero));
                }
        );

        resetar.setOnClickListener(
                v -> {
                    pontuacaoAtual.setText("");
                }
        );
    }

}