package br.ufpe.cin.residencia.datamanagement.room;

import androidx.lifecycle.ViewModel;

public class ProfessorViewModel extends ViewModel {


}
