package br.ufpe.cin.residencia.datamanagement.preferences;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import br.ufpe.cin.residencia.datamanagement.R;

public class PreferenceScreenActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preference_screen);
    }

}