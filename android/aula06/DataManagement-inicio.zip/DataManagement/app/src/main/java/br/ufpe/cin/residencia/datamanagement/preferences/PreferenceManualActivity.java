package br.ufpe.cin.residencia.datamanagement.preferences;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import br.ufpe.cin.residencia.datamanagement.R;

public class PreferenceManualActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preference_manual);
        final EditText campoTexto = findViewById(R.id.editTextUsername);
        final Button b = findViewById(R.id.salvarUsername);

        b.setOnClickListener(v -> {
            String oQueFoiDigitado = campoTexto.getText().toString();
        });
    }
}
