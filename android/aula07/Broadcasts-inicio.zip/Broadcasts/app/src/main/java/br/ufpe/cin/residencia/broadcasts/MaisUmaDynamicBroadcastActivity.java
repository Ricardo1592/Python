package br.ufpe.cin.residencia.broadcasts;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MaisUmaDynamicBroadcastActivity extends AppCompatActivity {
    TextView texto;
    int totalBroadcastsRecebidos = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dynamic_broadcast);

        Button enviarBroadcast1 = findViewById(R.id.enviarBroadcast1);
        Button enviarBroadcast2 = findViewById(R.id.enviarBroadcast2);
        enviarBroadcast1.setVisibility(View.GONE);
        enviarBroadcast2.setVisibility(View.GONE);
        texto = findViewById(R.id.texto);

    }


}