package br.ufpe.cin.residencia.broadcasts;

import android.content.Intent;
import android.os.BatteryManager;
import android.os.Bundle;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class BateriaActivity extends AppCompatActivity {

    private ProgressBar barra_carga = null;
    private TextView status_carga = null;
    private TextView nivel_carga = null;
    private TextView extrasIntent = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bateria);
        barra_carga = findViewById(R.id.barra_carga);
        status_carga = findViewById(R.id.status_carga);
        nivel_carga = findViewById(R.id.nivel_carga);
        extrasIntent = findViewById(R.id.extrasIntent);
    }

    private void atualizarStatusBateriaTela(Intent intent) {
        int pct =
                100 * intent.getIntExtra(BatteryManager.EXTRA_LEVEL, 1)
                        / intent.getIntExtra(BatteryManager.EXTRA_SCALE, 1);

        barra_carga.setProgress(pct);
        nivel_carga.setText(String.valueOf(pct) + "%");
        extrasIntent.setText(intent.getExtras().toString());

        switch (intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)) {
            case BatteryManager.BATTERY_STATUS_CHARGING:
                status_carga.setText("carregando");
                break;

            case BatteryManager.BATTERY_STATUS_FULL:
                int plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1);

                if (plugged == BatteryManager.BATTERY_PLUGGED_AC
                        || plugged == BatteryManager.BATTERY_PLUGGED_USB) {
                    status_carga.setText("bateria cheia, plugada");
                } else {
                    status_carga.setText("bateria cheia, mas descarregando");
                }
                break;

            default:
                status_carga.setText("bateria descarregando");
                break;
        }
    }
}