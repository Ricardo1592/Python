package br.ufpe.cin.residencia.broadcasts;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class SmsActivity extends AppCompatActivity {

    private static final String[] SMS_PERMISSIONS = {
            Manifest.permission.RECEIVE_SMS
    };
    private static final int SMS_REQUEST = 1001;

    TextView mensagem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);
        mensagem = findViewById(R.id.mensagem);
        if (!podeSMS()) {
            requestPermissions(SMS_PERMISSIONS, SMS_REQUEST);
        }
    }

    public boolean podeSMS() {
        return checkSelfPermission(Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case SMS_REQUEST:
                if (!podeSMS()) {
                    Toast.makeText(this, "Sem permissão para SMS", Toast.LENGTH_SHORT).show();
                    finish();
                }
                break;
        }
    }



    private void checkSMS(Intent intent) {
        Object[] rawMsgs = (Object[]) intent.getExtras().get("pdus");
        String format = intent.getStringExtra("format");
        if (format == null) {
            format = "3gpp";
        }
        for (Object raw : rawMsgs) {
            SmsMessage msg = SmsMessage.createFromPdu((byte[]) raw, format);

            if (msg.getMessageBody().toUpperCase().contains("RESIDENCIA")) {
                Toast.makeText(this, "Tem algo que nos interessa...", Toast.LENGTH_SHORT).show();
                mensagem.setText("Tem a palavra chave!");
            } else {
                mensagem.setText("Não tem a palavra chave...");
            }
        }
    }
}