package br.ufpe.cin.residencia.broadcasts;

import static br.ufpe.cin.residencia.broadcasts.MainActivity.ACTION_1;
import static br.ufpe.cin.residencia.broadcasts.MainActivity.ACTION_2;

import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class DynamicBroadcastActivity extends AppCompatActivity {
    TextView texto;
    ToastReceiver toastReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dynamic_broadcast);
        toastReceiver = new ToastReceiver();

        Button enviarBroadcast1 = findViewById(R.id.enviarBroadcast1);
        Button enviarBroadcast2 = findViewById(R.id.enviarBroadcast2);
        texto = findViewById(R.id.texto);

        enviarBroadcast1.setOnClickListener(
                v -> {
                    Intent i = new Intent(ACTION_1);
                    sendBroadcast(i);
                }
        );

        enviarBroadcast2.setOnClickListener(
                v -> {
                    Intent i = new Intent(ACTION_2);
                    sendBroadcast(i);
                }
        );
    }

    @Override
    protected void onStart() {
        super.onStart();
        registerReceiver(
                toastReceiver,
                new IntentFilter(
                        ACTION_1
                )
        );
    }

    @Override
    protected void onStop() {
        unregisterReceiver(toastReceiver);
        super.onStop();
    }
}