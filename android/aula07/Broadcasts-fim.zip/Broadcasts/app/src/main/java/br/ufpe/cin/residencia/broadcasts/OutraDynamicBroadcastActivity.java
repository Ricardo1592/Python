package br.ufpe.cin.residencia.broadcasts;

import static br.ufpe.cin.residencia.broadcasts.MainActivity.ACTION_1;
import static br.ufpe.cin.residencia.broadcasts.MainActivity.ACTION_2;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class OutraDynamicBroadcastActivity extends AppCompatActivity {
    TextView texto;
    int totalBroadcastsRecebidos = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dynamic_broadcast);

        Button enviarBroadcast1 = findViewById(R.id.enviarBroadcast1);
        Button enviarBroadcast2 = findViewById(R.id.enviarBroadcast2);
        texto = findViewById(R.id.texto);

        enviarBroadcast1.setOnClickListener(
                v -> {
                    Intent i = new Intent(ACTION_1);
                    sendBroadcast(i);
                }
        );

        enviarBroadcast2.setOnClickListener(
                v -> {
                    Intent i = new Intent(ACTION_2);
                    sendBroadcast(i);
                }
        );

    }

    BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            totalBroadcastsRecebidos++;
            texto.setText("Chegou um broadcast!\nACTION: "+intent.getAction()+"\nQuantidade total: "+totalBroadcastsRecebidos);
        }
    };

    @Override
    protected void onStart() {
        super.onStart();
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(ACTION_1);
        intentFilter.addAction(ACTION_2);
        registerReceiver(
                receiver,
                intentFilter
        );
    }

    @Override
    protected void onStop() {
        unregisterReceiver(receiver);
        super.onStop();
    }
}