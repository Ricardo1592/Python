package br.ufpe.cin.residencia.broadcasts;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    public static final String ACTION_1 = "br.ufpe.cin.residencia.broadcasts.ACTION";
    public static final String ACTION_2 = "br.ufpe.cin.residencia.broadcasts.OTHER_ACTION";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button enviarBroadcast = findViewById(R.id.enviarBroadcast);
        Button abrirActivity = findViewById(R.id.abrirActivity);
        Button abrirOutraActivity = findViewById(R.id.abrirOutraActivity);
        Button abrirMaisUmaActivity = findViewById(R.id.abrirMaisUmaActivity);
        Button smsActivity = findViewById(R.id.smsActivity);
        Button bateriaActivity = findViewById(R.id.bateriaActivity);

        enviarBroadcast.setOnClickListener(
                v -> {
                    Intent i = new Intent(ACTION_1);
                    sendBroadcast(i);
                }
        );


        abrirActivity.setOnClickListener(
                v -> startActivity(new Intent(this, DynamicBroadcastActivity.class))
        );

        abrirOutraActivity.setOnClickListener(
                v -> startActivity(new Intent(this, OutraDynamicBroadcastActivity.class))
        );

        abrirMaisUmaActivity.setOnClickListener(
                v -> startActivity(new Intent(this, MaisUmaDynamicBroadcastActivity.class))
        );

        bateriaActivity.setOnClickListener(
                v -> startActivity(new Intent(this, BateriaActivity.class))
        );

        smsActivity.setOnClickListener(
                v -> startActivity(new Intent(this, SmsActivity.class))
        );

    }
}