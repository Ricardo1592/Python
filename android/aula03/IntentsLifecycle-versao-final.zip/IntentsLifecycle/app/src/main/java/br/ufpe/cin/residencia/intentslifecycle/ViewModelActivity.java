package br.ufpe.cin.residencia.intentslifecycle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class ViewModelActivity extends AppCompatActivity {

    int activityId;
    boolean estadoSwitch;
    TextView lifecycleLog, identificadores, textoExibido;
    LifecycleViewModel viewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lifecycle);
        estadoSwitch = false;

        //das duas uma:
        //1. o onCreate está rodando pela primeira vez, e a linha abaixo vai resultar em um novo objeto sendo criado
        //2. ou houve uma mudança de config. e já existe um objeto ViewModel que vai ser devolvido pela chamada abaixo
        viewModel = new ViewModelProvider(this).get(LifecycleViewModel.class);
        activityId = new Random().nextInt();

        identificadores = findViewById(R.id.identificadores);
        lifecycleLog = findViewById(R.id.lifecycle);
        textoExibido = findViewById(R.id.textoDigitado);
        EditText campoTexto = findViewById(R.id.campoTexto);
        Button botao = findViewById(R.id.botao);
        Switch swytch = findViewById(R.id.swytch);

        swytch.setOnCheckedChangeListener(
                (buttonView, isChecked) -> {
                    estadoSwitch = isChecked;
                }
        );

        botao.setOnClickListener(
                v -> {
                    String oQueFoiDigitado = campoTexto.getText().toString();
                    textoExibido.setText(oQueFoiDigitado);
                    viewModel.textoExibidoNaTela = oQueFoiDigitado;
                    Toast.makeText(this, "Estado atual do switch: "+estadoSwitch, Toast.LENGTH_SHORT).show();
                }
        );

        identificadores.setText(getString(R.string.identificadoresInicial, activityId));
        lifecycleLog.setText(viewModel.logCicloDeVida);
        textoExibido.setText(viewModel.textoExibidoNaTela);
        log("onCreate()");

    }

    @Override
    protected void onStart() {
        super.onStart();
        log("onStart()");
    }

    @Override
    protected void onResume() {
        super.onResume();
        log("onResume()");
    }

    @Override
    protected void onPause() {
        log("onPause()");
        super.onPause();
    }

    @Override
    protected void onStop() {
        log("onStop()");
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        log("onDestroy()");
        super.onDestroy();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        log("onRestart()");
    }

    private void log(String msg) {
        msg = msg + " | "+activityId + " | " + viewModel.viewModelId;
        String log = lifecycleLog.getText().toString()+'\n'+msg;
        viewModel.logCicloDeVida = log;
        lifecycleLog.setText(log);
        Log.d("LIFECYCLELOG", msg);
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}