package br.ufpe.cin.residencia.intentslifecycle;

import androidx.lifecycle.ViewModel;

import java.util.Random;

public class LifecycleViewModel extends ViewModel {
    //guardando estado (dados) em separado da Activity
    String textoExibidoNaTela = "valor padrão";
    String logCicloDeVida = "início do log...";
    final int viewModelId = new Random().nextInt();
}
