package br.ufpe.cin.residencia.recyclerview;

public class Constants {

    public static final Pessoa[] professores = {
            new Pessoa("Leopoldo", "lmt"),
            new Pessoa("Juliano", "jmi"),
            new Pessoa("Henrique", "hemr"),
            new Pessoa("Jessyka", "jffv"),
            new Pessoa("Roberto", "roberto"),
            new Pessoa("Alexandre", "acm"),
            new Pessoa("Hermano", "hermano"),
            new Pessoa("Vinicius", "vcg"),
            new Pessoa("Ricardo Prudêncio", "rbcp"),
            new Pessoa("Flavia", "fab"),
            new Pessoa("Carla", "ctlls"),
            new Pessoa("Breno", "bafm"),
            new Pessoa("Sergio", "scbs"),
            new Pessoa("Paulo Borba", "phmb"),
            new Pessoa("Augusto", "acas"),
            new Pessoa("Tsang", "tir"),
            new Pessoa("Castor", "fjclf"),
            new Pessoa("Marcelo", "damorim"),
            new Pessoa("Kiev", "kiev"),
            new Pessoa("Marcio", "mlc2"),
            new Pessoa("Gustavo", "ghpc")
    };
}