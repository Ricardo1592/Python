package br.ufpe.cin.residencia.hello;

import android.view.View;

public class Teste implements View.OnClickListener {
    @Override
    public void onClick(View v) {
//        mensagemExibida.setText("Clicou no botão");
    }
}
