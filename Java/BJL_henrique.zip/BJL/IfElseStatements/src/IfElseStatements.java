
public class IfElseStatements {

	public static void main(String[] args) {
//		If student's grade is grater than or equal to 60%
//		   Print "Passed"
//		Else
//		   Print "Failed"
		
		int grade = 50;
		
		if(grade == 60){
			System.out.println("Passed");
		}
		else if(grade > 60){
			System.out.println("Passed");
		}
		else {
			System.out.println("Failed");
		}
	}
}
