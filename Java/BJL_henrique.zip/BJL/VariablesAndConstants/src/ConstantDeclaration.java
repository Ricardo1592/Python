
public class ConstantDeclaration {

	public static void main(String[] args) {
		final double BOTTLE_VOLUME = 2; // liters
//		BOTTLE_VOLUME = 4; // this is not allowed...!
		System.out.println("A bottle volume is = "+BOTTLE_VOLUME);
	}
}
