
public class VariableDeclaration {

	public static void main(String[] args) {
		int cansPerPack; // variable declaration
		cansPerPack = 6;//  variable assignment
//		int cansPerPack = 6; // variable declaration and initialization
		System.out.println("Total cans per pack = "+cansPerPack);	
	}
}
