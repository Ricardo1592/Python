
public class Exp {
	
	public static void main(String[] args) {
		System.out.println("Expressions in Java");
		System.out.println("--------------------");
		System.out.println();
		System.out.println(3 + 4);
		System.out.println(3 + (2 * 3));
		System.out.println("3 + 4 = "+(3 + 4));
		System.out.println("3 + (2 * 3) = "+(3 + (2 * 3)));
		System.out.println("12 / (2 * 3) = " + (12 / (2 * 3)));
		System.out.println(Math.sqrt(16));
		System.out.println(Math.pow(3, 2));
		System.out.println(Math.pow(3, 3));
	}

}
