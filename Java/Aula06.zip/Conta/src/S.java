
public class S  extends T{
	
	public S() {
		super();
	}

}
